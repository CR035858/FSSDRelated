// Get references to HTML elements
const taskInput = document.getElementById('taskInput');
const addTaskButton = document.getElementById('addTask');
const taskList = document.getElementById('taskList');
const showCompletedCheckbox = document.getElementById('showCompleted');

// Create an array to store tasks
let tasks = [];

// Add a click event listener to the "Add Task" button
addTaskButton.addEventListener('click', () => addTask());

// Add a change event listener to the "Show Completed" checkbox
showCompletedCheckbox.addEventListener('change', () => renderTasks());

// Function to add a new task
function addTask() {
    // Get the text from the input field and remove any leading/trailing spaces
    const taskText = taskInput.value.trim();
    if (taskText === '') return;

    // Create a new task object with text, completion status, and deleted status
    const newTask = { text: taskText, completed: false, deleted: false };
    tasks.push(newTask); // Add the new task to the tasks array

    taskInput.value = ''; // Clear the input field
    renderTasks(); // Update the task list
}

// Function to render tasks in the task list
function renderTasks() {
    taskList.innerHTML = ''; // Clear the existing task list
    const showCompleted = showCompletedCheckbox.checked; // Check if the "Show Completed" checkbox is checked

    // For loop to iterate through each task from the array of the tasks
    for (let index = 0; index < tasks.length; index++) {
        const { text, completed, deleted } = tasks[index];

        // Check if the task is not marked as deleted and should be displayed based on the "Show Completed" checkbox
        if (!deleted && (showCompleted || !completed)) {
            // Create a new list item (task)
            const li = document.createElement('li');

            // Build the HTML structure for the task, including checkbox, task description, and delete button
            li.innerHTML = `
                <input type="checkbox" ${completed ? 'checked' : ''}>
                <span class="task ${completed ? 'completed' : ''}">${text}</span>
                <button class="delete">Delete</button>
            `;

            // Add a click event listener to the delete button to remove the task
            const deleteButton = li.querySelector('.delete');
            deleteButton.addEventListener('click', () => deleteTask(index));

            // Add a change event listener to the checkbox to toggle the task status as either active or completed
            const checkbox = li.querySelector('input[type="checkbox"]');
            checkbox.addEventListener('change', () => toggleCompletion(index));

            // Add the new task to the task list
            taskList.appendChild(li);
        }
    }
}

// Function to mark a task as deleted
function deleteTask(index) {
    tasks[index].deleted = true;
    renderTasks(); // Update the task list
}

// Function to toggle the completion status of a task
function toggleCompletion(index) {
    tasks[index].completed = !tasks[index].completed;
    renderTasks(); // Update the task list
}

// Initially render the tasks when the page loads
renderTasks();
