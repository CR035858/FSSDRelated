// Get references to HTML elements
const taskInput = document.getElementById('taskInput');
const taskList = document.getElementById('taskList');
const showAllButton = document.getElementById('showAll');
const showActiveButton = document.getElementById('showActive');
const showCompletedButton = document.getElementById('showCompleted');

// Create an array to store tasks
const tasks = [];

// Add click event listeners to the "All," "Active," and "Completed" filter buttons
showAllButton.addEventListener('click', () => renderFilteredTasks('all'));
showActiveButton.addEventListener('click', () => renderFilteredTasks('active'));
showCompletedButton.addEventListener('click', () => renderFilteredTasks('completed'));

//Get the Add Task button
const addTaskButton = document.getElementById('addTask');

//Add an event listener to display form on clicking Add Task button
addTaskButton.addEventListener('click', () => { document.getElementById('addTaskForm').style.display = ""; });

//Get the Form for adding task
const addTaskForm = document.getElementById('addTaskForm');

//Set the event listener for submit event on form
addTaskForm.addEventListener('submit', (event) => {
    //So that web page does not reload
    event.preventDefault();

    // Capture task details from the form fields
    const taskName = document.getElementById('taskName').value;
    const description = document.getElementById('description').value;
    const dueDate = document.getElementById('dueDate').value;
    const dueTime = document.getElementById('dueTime').value;

    // Create a formatted due date and time if both dueDate and dueTime are provided,
    // using them to construct a date-time string, and converting it to a user-friendly
    // localized string format; if either dueDate or dueTime is missing, set it to null
    const formattedDueDateAndTime = dueDate ? new Date(dueDate + 'T' + dueTime).toLocaleString() : null;

    //Call addTask to save task details into the tasks array
    addTask(taskName, description, formattedDueDateAndTime);

    //Reset the form to clear all input values
    addTaskForm.reset();

    //Hide the form
    addTaskForm.style.display = "none";
});

// Function to add a new task
function addTask(taskName, description, dueDateAndTime) {
    // Create a new task object with task name, task description, due date and time of task completion, completion status, and deleted status
    const newTask = { name: taskName, description: description, dueDateAndTime: dueDateAndTime, completed: false, deleted: false };
    tasks.push(newTask); // Add the new task to the tasks array
    renderFilteredTasks('all'); // Update the task list to show all tasks
}

// Function to render tasks based on the selected filter
function renderFilteredTasks(filterType) {
    const filteredTasks = filterTasks(filterType);
    renderTasks(filteredTasks);
}

// Function to filter tasks based on the selected filter type
function filterTasks(filterType) {
    resetButtonsBackground();
    switch (filterType) {
        case 'all':
            showAllButton.style.background = "#3F3047"; // Highlight the "All" button
            return tasks.filter(task => !task.deleted);
        case 'active':
            showActiveButton.style.background = "#3F3047"; // Highlight the "Active" button
            return tasks.filter(task => !task.completed && !task.deleted);
        case 'completed':
            showCompletedButton.style.background = "#3F3047"; // Highlight the "Completed" button
            return tasks.filter(task => task.completed && !task.deleted);
        default:
            return [];
    }
}

// Function to render tasks in the task list
function renderTasks(filteredTasks) {
    taskList.innerHTML = ''; // Clear the existing task list
    // Iterate through each of the filtered tasks from the array
    filteredTasks.forEach((task) => {
        if (!task.deleted) { // Check if the task is not marked as deleted
            // Create a new table row to add the task details
            const tr = document.createElement('tr');

            // Build the HTML structure for the task, including checkbox, task name, task description, due date and time, and delete button
            tr.innerHTML = `
                <td><input type="checkbox" ${task.completed ? 'checked' : ''}></td>
                <td>${task.name}</td>
                <td>${task.description}</td>
                <td>${task.dueDateAndTime}</td>
                <td><button class="delete">Delete</button></td>
            `;
            
            // Add a click event listener to the delete button to remove the task
            const deleteButton = tr.querySelector('.delete');
            deleteButton.addEventListener('click', () => deleteTask(tasks.indexOf(task)));

            // Add a change event listener to the checkbox to toggle the task status as either active or completed
            const checkbox = tr.querySelector('input[type="checkbox"]');
            checkbox.addEventListener('change', () => toggleCompletion(tasks.indexOf(task)));

            // Add the new task to the task table
            taskList.appendChild(tr);
        }
    });
}

// Function to reset the background color of filter buttons
function resetButtonsBackground(){
    showAllButton.style.background = "#007BFF";
    showActiveButton.style.background = "#007BFF";
    showCompletedButton.style.background = "#007BFF";
}

// Function to mark a task as deleted
function deleteTask(index) {
    tasks[index].deleted = true;
    renderFilteredTasks('all'); // Update the task list to show all tasks
}

// Function to toggle the completion status of a task
function toggleCompletion(index) {
    tasks[index].completed = !tasks[index].completed;
    renderFilteredTasks('all'); // Update the task list to show all tasks
}

// Initially render all the tasks when the page loads
renderFilteredTasks('all');