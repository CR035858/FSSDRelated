// Get references to HTML elements
const taskInput = document.getElementById('taskInput');
const addTaskButton = document.getElementById('addTask');
const taskList = document.getElementById('taskList');
const showAllButton = document.getElementById('showAll');
const showActiveButton = document.getElementById('showActive');
const showCompletedButton = document.getElementById('showCompleted');

// Create an array to store tasks
const tasks = [];

// Add a click event listener to the "Add Task" button
addTaskButton.addEventListener('click', () => addTask());

// Add click event listeners to the "All," "Active," and "Completed" filter buttons
showAllButton.addEventListener('click', () => renderFilteredTasks('all'));
showActiveButton.addEventListener('click', () => renderFilteredTasks('active'));
showCompletedButton.addEventListener('click', () => renderFilteredTasks('completed'));

// Function to add a new task
function addTask() {
    // Get the text from the input field and remove any leading/trailing spaces
    const taskText = taskInput.value.trim();
    if (taskText === '') return;

    // Create a new task object with text, completion status, and deleted status
    const newTask = { text: taskText, completed: false, deleted: false };
    tasks.push(newTask); // Add the new task to the tasks array

    taskInput.value = ''; // Clear the input field
    renderFilteredTasks('all'); // Update the task list to show all tasks
}

// Function to render tasks based on the selected filter
function renderFilteredTasks(filterType) {
    const filteredTasks = filterTasks(filterType);
    renderTasks(filteredTasks);
}

// Function to filter tasks based on the selected filter type
function filterTasks(filterType) {
    resetButtonsBackground();
    switch (filterType) {
        case 'all':
            showAllButton.style.background = "#3F3047"; // Highlight the "All" button
            return tasks.filter(task => !task.deleted);
        case 'active':
            showActiveButton.style.background = "#3F3047"; // Highlight the "Active" button
            return tasks.filter(task => !task.completed && !task.deleted);
        case 'completed':
            showCompletedButton.style.background = "#3F3047"; // Highlight the "Completed" button
            return tasks.filter(task => task.completed && !task.deleted);
        default:
            return [];
    }
}

// Function to render tasks in the task list
function renderTasks(filteredTasks) {
    taskList.innerHTML = ''; // Clear the existing task list
    // Iterate through each of the tasks from the array
    filteredTasks.forEach((task) => {
        if (!task.deleted) { // Check if the task is not marked as deleted
            // Create a new list item (task)
            const li = document.createElement('li');

            // Build the HTML structure for the task, including checkbox, task description, and delete button
            li.innerHTML = `
                <input type="checkbox" ${task.completed ? 'checked' : ''}>
                <span class="task ${task.completed ? 'completed' : ''}">${task.text}</span>
                <button class="delete">Delete</button>
            `;

            // Add a click event listener to the delete button to remove the task
            const deleteButton = li.querySelector('.delete');
            deleteButton.addEventListener('click', () => deleteTask(tasks.indexOf(task)));

            // Add a change event listener to the checkbox to toggle the task status as either active or completed
            const checkbox = li.querySelector('input[type="checkbox"]');
            checkbox.addEventListener('change', () => toggleCompletion(tasks.indexOf(task)));

            // Add the new task to the task list
            taskList.appendChild(li);
        }
    });
}

// Function to reset the background color of filter buttons
function resetButtonsBackground(){
    showAllButton.style.background = "#007BFF";
    showActiveButton.style.background = "#007BFF";
    showCompletedButton.style.background = "#007BFF";
}

// Function to mark a task as deleted
function deleteTask(index) {
    tasks[index].deleted = true;
    renderFilteredTasks('all'); // Update the task list to show all tasks
}

// Function to toggle the completion status of a task
function toggleCompletion(index) {
    tasks[index].completed = !tasks[index].completed;
    renderFilteredTasks('all'); // Update the task list to show all tasks
}

// Initially render all the tasks when the page loads
renderFilteredTasks('all');