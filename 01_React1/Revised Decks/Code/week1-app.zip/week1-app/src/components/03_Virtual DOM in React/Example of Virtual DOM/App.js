//Replace the App.js present in the src folder with this file 
//to run the Virtual DOM example as provided in 03_Virtual DOM in React deck

import React from 'react';
import Counter from './components/03_Virtual DOM in React/Example of Virtual DOM/Counter';
const App = () => {
  
  return (
   <>
   <Counter/>
   </>
  );
};

export default App;
