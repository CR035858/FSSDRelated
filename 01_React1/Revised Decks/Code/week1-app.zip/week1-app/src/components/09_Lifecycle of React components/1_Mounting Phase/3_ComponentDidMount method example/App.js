//Replace the App.js present in the src folder with this file 
//to run the componentDidMount() example as provided in 09_Lifecycle of React components

import React from 'react';
import MyComponent from './components/09_Lifecycle of React components/1_Mounting Phase/3_ComponentDidMount method example/MyComponent';
const App = () => {
  
  return (
   <>
   <MyComponent/>
   </>
  );
};

export default App;
