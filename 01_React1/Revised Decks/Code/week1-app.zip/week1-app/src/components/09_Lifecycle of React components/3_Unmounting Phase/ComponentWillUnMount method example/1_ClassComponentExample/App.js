//Replace the App.js present in the src folder with this file 
//to run the ClassComponentExample of componentWillUnmount() example as provided in 09_Lifecycle of React components

import React from 'react';
import MyComponent from './components/09_Lifecycle of React components/3_Unmounting Phase/ComponentWillUnMount method example/1_ClassComponentExample/MyComponent';
const App = () => {
  
  return (
   <>
   <MyComponent/>
   </>
  );
};

export default App;
