//Replace the App.js present in the src folder with this file 
//to run the Bootstrap using npm example as provided in 08_Bootstrap in React deck

import React from 'react';
import MyButton from './components/08_Bootstrap in React/2_Bootstrap using npm/MyButton';
function App() {
  return (
    <div className="container">
      <MyButton/>
    </div>
  );
}
export default App;
