//Replace the App.js present in the src folder with this file 
//to run the Bootstrap using CDN example as provided in 08_Bootstrap in React deck

import React from 'react';

function App() {
  return (
    <div className="container">
      <h1>Hello, world!</h1>
      <p>This is a Bootstrap-styled React app.</p>
      <button className="btn btn-primary">Click me</button>
    </div>
  );
}
export default App;
