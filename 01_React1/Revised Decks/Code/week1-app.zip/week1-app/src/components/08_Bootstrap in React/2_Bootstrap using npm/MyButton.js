import React from 'react';
function MyButton() {
  return (
    <button className="btn btn-primary">Click me</button>
  );
}
export default MyButton;
