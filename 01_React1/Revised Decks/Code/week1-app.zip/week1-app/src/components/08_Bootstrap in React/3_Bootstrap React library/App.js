//Replace the App.js present in the src folder with this file 
//to run the Bootstrap React Library example as provided in 08_Bootstrap in React deck

import React from 'react';
import MyComponent from './components/08_Bootstrap in React/3_Bootstrap React library/MyComponent';
function App() {
  return (
    <div className="container">
      <MyComponent/>
    </div>
  );
}
export default App;
