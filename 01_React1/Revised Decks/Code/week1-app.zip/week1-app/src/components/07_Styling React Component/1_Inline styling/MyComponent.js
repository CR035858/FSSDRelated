const MyComponent = () => {
  return (
    <div style={{ backgroundColor: 'blue', color: 'white' }}>
      Hello World
    </div>
  );
};

export default MyComponent;