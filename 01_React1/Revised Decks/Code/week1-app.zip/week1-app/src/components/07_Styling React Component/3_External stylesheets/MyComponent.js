import './MyComponent.css';

const MyComponent = () => {
  return (
    <div className="my-component">
      Hello World
    </div>
  );
};

export default MyComponent;