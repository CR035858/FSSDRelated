import Button from 'react-bootstrap/Button';

function MyComponent() {
  return <Button variant="primary">Click me</Button>;
}

export default MyComponent;