//Replace the App.js present in the src folder with this file 
//to run the Inline styling  with style object example as provided in 07_Styling React Component deck

import React from 'react';
import MyComponent from './components/07_Styling React Component/1_Inline styling/MyComponent';
const App = () => {
  
  return (
   <>
   <MyComponent/>
   </>
  );
};

export default App;
