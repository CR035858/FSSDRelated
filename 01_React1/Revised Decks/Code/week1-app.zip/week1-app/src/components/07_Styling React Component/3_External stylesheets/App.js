//Replace the App.js present in the src folder with this file 
//to run the External stylesheets example as provided in 07_Styling React Component deck

import React from 'react';
import MyComponent from './components/07_Styling React Component/3_External stylesheets/MyComponent';
const App = () => {
  
  return (
   <>
   <MyComponent/>
   </>
  );
};

export default App;
