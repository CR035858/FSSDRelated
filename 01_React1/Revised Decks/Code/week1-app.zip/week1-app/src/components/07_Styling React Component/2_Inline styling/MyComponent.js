const styles = {
  backgroundColor: 'red',
  color: 'white',
  padding: '10px',
  borderRadius: '5px',
}

function MyComponent() {
  return <div style={styles}>Hello, World!</div>
}
export default MyComponent;