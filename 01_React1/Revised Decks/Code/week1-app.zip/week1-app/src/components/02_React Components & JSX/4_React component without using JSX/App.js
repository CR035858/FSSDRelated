//Replace the App.js present in the src folder with this file 
//to run the React component without using JSX example as provided in 03_React Components & JSX deck

import React from 'react';
import HelloWorld from './components/02_React Components & JSX/4_React component without using JSX/HelloWorld';
const App = () => {
  return (
    <div>
     <HelloWorld/>
    </div>
  );
};
export default App;
