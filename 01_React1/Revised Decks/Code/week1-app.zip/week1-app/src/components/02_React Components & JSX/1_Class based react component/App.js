//Replace the App.js present in the src folder with this file 
//to run the Class based component example as provided in 03_React Components & JSX deck

import React from 'react';
import MyComponent from './components/02_React Components & JSX/1_Class based react component/MyComponent';
const App = () => {
  
  return (
   <>
   <MyComponent/>
   </>
  );
};

export default App;
