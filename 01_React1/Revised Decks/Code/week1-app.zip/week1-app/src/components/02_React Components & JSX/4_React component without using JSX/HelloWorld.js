import React from 'react';

const HelloWorld = () => {
  return React.createElement('div', null, 'Hello, World!');
};

export default HelloWorld;
