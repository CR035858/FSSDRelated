//Replace the App.js present in the src folder with this file 
//to run the State in React component example as provided in 04_Implementing props and state in components deck

import React from 'react';
import Example from './components/05_Implementing props and state in components/3_State in React component/Example';
const App = () => {
  
  return (
    <div>
    <Example/>
  </div>

  );
};

export default App;
