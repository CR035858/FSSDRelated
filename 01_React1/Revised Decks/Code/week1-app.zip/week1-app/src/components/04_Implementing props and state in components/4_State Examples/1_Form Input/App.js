//Replace the App.js present in the src folder with this file 
//to run the Form Input example as provided in 04_Implementing props and state in components deck

import React from 'react';
import Form from './components/05_Implementing props and state in components/4_State Examples/1_Form Input/Form';
const App = () => {
  
  return (
    <div>
    <Form/>
  </div>

  );
};

export default App;
