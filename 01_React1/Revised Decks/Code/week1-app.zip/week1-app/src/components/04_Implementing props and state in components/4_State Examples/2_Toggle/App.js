//Replace the App.js present in the src folder with this file 
//to run the Toggle example as provided in 04_Implementing props and state in components deck

import React from 'react';
import Toggle from './components/05_Implementing props and state in components/4_State Examples/2_Toggle/Toggle';
const App = () => {
  
  return (
    <div>
    <Toggle/>
  </div>

  );
};

export default App;
