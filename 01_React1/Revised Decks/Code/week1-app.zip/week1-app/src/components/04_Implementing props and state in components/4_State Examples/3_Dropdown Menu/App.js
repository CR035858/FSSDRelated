//Replace the App.js present in the src folder with this file 
//to run the Dropdown Menu example as provided in 04_Implementing props and state in components deck

import React from 'react';
import DropdownMenu from './components/05_Implementing props and state in components/4_State Examples/3_Dropdown Menu/DropdownMenu';
const App = () => {
  
  return (
    <div>
    <DropdownMenu/>
  </div>

  );
};

export default App;
