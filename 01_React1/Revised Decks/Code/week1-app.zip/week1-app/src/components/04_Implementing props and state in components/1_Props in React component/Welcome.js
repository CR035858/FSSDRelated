import React from 'react';

function Welcome(props) {
  return <h1>Hi, {props.name} Have a nice day!</h1>;
}

export default Welcome;