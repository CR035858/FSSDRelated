export const credentials = {
    "harry1992": "harrypotter1992",
    "ron1993": "ronweasley1993"
}

localStorage.setItem("credentials", JSON.stringify(credentials))